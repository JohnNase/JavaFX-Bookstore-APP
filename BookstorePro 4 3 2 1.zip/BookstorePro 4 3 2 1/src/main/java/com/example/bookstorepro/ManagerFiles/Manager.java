package com.example.bookstorepro.ManagerFiles;

import com.example.bookstorepro.LibrarianFiles.Librarian;

public class Manager extends Librarian {
    public Manager(){
    }
    public Manager(String username, String password, String role){
        super(username, password, role);
    }


}
